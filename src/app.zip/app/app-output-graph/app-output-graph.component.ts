import { Component, OnInit } from '@angular/core';
import * as Highcharts from 'highcharts';

declare var require: any;
let Boost = require('highcharts/modules/boost');
let noData = require('highcharts/modules/no-data-to-display');
let More = require('highcharts/highcharts-more');

Boost(Highcharts);
noData(Highcharts);
More(Highcharts);
noData(Highcharts);

@Component({
  selector: 'cio-app-output-graph',
  templateUrl: './app-output-graph.component.html',
  styleUrls: ['./app-output-graph.component.css']
})
export class AppOutputGraphComponent implements OnInit {
  public options: any = {

    chart: {
      type: 'line'
    },
    title: {
      text: 'Monthly Average Vaccination'
    },
    subtitle: {
      text: 'Source: Barangay Mintal'
    },
    xAxis: {
      categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
    },
    yAxis: {
      title: {
        text: 'No. of children'
      }
    },
    plotOptions: {
      line: {
        dataLabels: {
          enabled: true
        },
        enableMouseTracking: false
      }
    },
    series: [{
      name: 'Male',
      data: [7.0, 6.9, 9.5, 14.5, 18.4, 21.5, 25.2, 26.5, 23.3, 18.3, 13.9, 9.6]
    }, {
      name: 'Female',
      data: [3.9, 4.2, 5.7, 8.5, 11.9, 15.2, 17.0, 16.6, 14.2, 10.3, 6.6, 4.8]
    }]
    // chart: {
    //   type: 'scatter',
    //   height: 700
    // },
    // title: {
    //   text: 'Sample Scatter Plot'
    // },
    // credits: {
    //   enabled: false
    // },
    // tooltip: {
    //   formatter: function() {
    //     return 'x: ' + Highcharts.dateFormat('%e %b %y %H:%M:%S', this.x) +
    //       ' y: ' + this.y.toFixed(2);
    //   }
    // },
    // xAxis: {
    //   type: 'datetime',
    //   labels: {
    //     formatter: function() {
    //       return Highcharts.dateFormat('%e %b %y', this.value);
    //     }
    //   }
    // },
    // series: [
    //   {
    //     name: 'Normal',
    //     turboThreshold: 500000,
    //     data: [[new Date('2018-01-25 18:38:31').getTime(), 2]]
    //   },
    //   {
    //     name: 'Abnormal',
    //     turboThreshold: 500000,
    //     data: [[new Date('2018-02-05 18:38:31').getTime(), 7]]
    //   }
    // ]
  }
  constructor() { }

  ngOnInit() {
    Highcharts.chart('container', this.options);
  }
}
