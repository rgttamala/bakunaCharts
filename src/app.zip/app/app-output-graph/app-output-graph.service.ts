import { Injectable } from '@angular/core';
import { HttpClient } from 'selenium-webdriver/http';
import { environment } from 'src/environments/environment.prod';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AppOutputGraphService {

  apiUrl: any;

  constructor(private http: HttpClient) {
    this.apiUrl = environment.apiUrl;
  }

  // getAllReports() {
  //   return this.http.get(this.apiUrl + 'allUsers/')
  //     .pipe(map((response: any) => {
  //       return response.json();
  //     }));
  // }

  // getUsers(): Observable<{ data: Users[] }> {
  //   const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  //   return this.http.get<{ status_code: number, data: Users[], message: string }>(this.apiUrl +
  //     'allUsers', { headers: headers });
  // }
}
