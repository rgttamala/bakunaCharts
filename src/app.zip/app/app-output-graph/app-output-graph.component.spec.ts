import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppOutputGraphComponent } from './app-output-graph.component';

describe('AppOutputGraphComponent', () => {
  let component: AppOutputGraphComponent;
  let fixture: ComponentFixture<AppOutputGraphComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppOutputGraphComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppOutputGraphComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
